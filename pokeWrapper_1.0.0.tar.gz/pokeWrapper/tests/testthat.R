library(testthat)
library(pokeWrapper)

test_check("pokeWrapper")
